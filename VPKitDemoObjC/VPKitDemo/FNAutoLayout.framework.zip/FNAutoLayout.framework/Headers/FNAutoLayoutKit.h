//
//  FNAutoLayoutKit.h
//  FNAutoLayout
//
//  Created by jonathan on 18/08/2015.
//  Copyright (c) 2015 foundry. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FNAutoLayout_CategoryIncluder.h"
#import "FNLazyObjects.h"
/*
 this method should be calld from the application to get category-only files included
 */

@interface FNAutoLayoutKit : NSObject
+ (void)start;
@end
