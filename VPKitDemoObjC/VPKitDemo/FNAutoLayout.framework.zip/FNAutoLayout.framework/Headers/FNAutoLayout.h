//
//  FNAutoLayout.h
//  FNAutoLayout
//
//  Created by jonathan on 18/08/2015.
//  Copyright (c) 2015 foundry. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FNAutoLayout.
FOUNDATION_EXPORT double FNAutoLayoutVersionNumber;

//! Project version string for FNAutoLayout.
FOUNDATION_EXPORT const unsigned char FNAutoLayoutVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FNAutoLayout/PublicHeader.h>

#import <FNAutoLayout/FNAutoLayoutKit.h>
