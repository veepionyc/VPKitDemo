//
//  FNLazyLayout.h
//  FNAutoLayout
//
//  Created by jonathan on 19/08/2015.
//  Copyright (c) 2015 foundry. All rights reserved.
//

#ifndef FNAutoLayout_FNLazyLayout_h
#define FNAutoLayout_FNLazyLayout_h


#define lazyObject(class,name)                                          \
- (class*)name {                                                        \
if (!_##name) {                                                         \
_##name = [[class alloc] init];                                         \
}                                                                       \
return _##name;                                                         \
}                                                                       \

#define lazyView(class,name)                                            \
- (class*)name {                                                        \
if (!_##name) {                                                         \
_##name = [[class alloc] init];                                         \
}                                                                       \
return _##name;                                                         \
}                                                                       \

#define lazyViewWithAutolayout(class,name)                              \
- (class*)name {                                                        \
if (!_##name) {                                                         \
_##name = [[class alloc] init];                                         \
_##name.translatesAutoresizingMaskIntoConstraints = NO;                 \
}                                                                       \
return _##name;                                                         \
}                                                                       \



#define lazyAddView(class,name)                                         \
- (class*)name {                                                        \
if (!_##name) {                                                         \
_##name = [[class alloc] init];                                         \
if ([self respondsToSelector:@selector(contentView)]) {                 \
[[(id)self contentView] addSubview:_##name];                            \
} else if ([self respondsToSelector:@selector(addSubview:)]) {          \
[(id)self addSubview:_##name];                                          \
} else {                                                                \
[[(id)self view] addSubview:_##name];                                   \
}                                                                       \
}                                                                       \
return _##name;                                                         \
}                                                                       \



#define lazyAddViewWithAutolayout(class,name)                           \
- (class*)name {                                                        \
if (!_##name) {                                                         \
_##name = [[class alloc] init];                                         \
_##name.translatesAutoresizingMaskIntoConstraints = NO;                 \
if ([self respondsToSelector:@selector(contentView)]) {                 \
[[(id)self contentView] addView:_##name withName:@#name];               \
} else if ([self respondsToSelector:@selector(addSubview:)]) {          \
[(id)self addView:_##name withName:@#name];                             \
} else {                                                                \
[[(id)self view] addView:_##name withName:@#name];                      \
}                                                                       \
}                                                                       \
return _##name;                                                         \
}                                                                       \


#define lazyAddViewToViewController(class,name)                         \
- (class*)name {                                                        \
if (!_##name) {                                                         \
_##name = [[class alloc] init];                                         \
[self.view addSubview:_##name];                                         \
}                                                                       \
return _##name;                                                         \
}                                                                       \

#define lazyAddViewToViewControllerWithAutolayout(class,name)           \
- (class*)name {                                                        \
if (!_##name) {                                                         \
_##name = [[class alloc] init];                                         \
_##name.translatesAutoresizingMaskIntoConstraints = NO;                 \
[self.view addView:_##name withName:@#name];                            \
}                                                                       \
return _##name;                                                         \
}                                                                       \


#define AddViewWithAutolayout(subview)                                  \
subview.translatesAutoresizingMaskIntoConstraints = NO;                 \
if ([self respondsToSelector:@selector(contentView)]) {                 \
[[(id)self contentView] addView:subview withName:@#subview];            \
} else if ([self respondsToSelector:@selector(addSubview:)]) {          \
[(id)self addView:subview withName:@#subview];                          \
} else {                                                                \
[[(id)self view] addView:subview withName:@#subview];                   \
}                                                                       \


#endif
