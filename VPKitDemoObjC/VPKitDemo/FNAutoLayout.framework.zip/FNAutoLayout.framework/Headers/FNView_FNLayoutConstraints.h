//
//  FNView+FNLayoutConstraints.h
//  Foundry
//
//  Created by jonathan on 25/06/2014.
//  Copyright (c) 2014 Foundry. All rights reserved.
//
@import Foundation;
#if TARGET_OS_IPHONE
@import UIKit;
#define FNView UIView

#else
@import AppKit;
#define FNView NSView
#define UIEdgeInsets NSEdgeInsets
#define UIEdgeInsetsZero NSEdgeInsetsZero

#endif

void use_FNLayoutConstraints();
extern NSInteger FORCE_LOAD_FNLayoutConstraints;


// Collection of helpers to manage autolayout

@interface FNView (FNLayoutConstraints)
- (void)testAmbiguity;

/*
 clearConstraints removes constraints associated from that view
 both from self and from the view passed in. 
 This gets rid of unary (intrinsic) constraints.
 */
//- (void)clearConstraints; // for auto-created subviewsUnderConstraints array
- (void)clearConstraintsForSubviews; //same as clearConstraints
- (void)clearConstraintsForViews:(NSArray*)views;
- (void)clearConstraintsForView:(FNView*)view;

/*
 removeConstraints removes constraints associated from that view
 from self only, so leaves unary constraints in place
 */
//- (void)removeConstraints; // for auto-created subviewsUnderConstraints array
- (void)removeConstraintsForSelf;
- (void)removeConstraintsForSubviews; //as removeConstraints
- (void)removeConstraintsForViews:(NSArray*)views;
- (void)removeConstraintsFromSuperview;


- (void)centerXinSuperview; // horizontally
- (void)centerYinSuperview; // vertically
- (void)centerInSuperview;

- (void)centerXinSuperviewWithOffset:(CGFloat)offset;
- (void)centerYinSuperviewWithOffset:(CGFloat)offset;

- (void)alignLeft:(CGFloat)offset;
- (void)alignTop:(CGFloat)offset;
- (void)alignRight:(CGFloat)offset;
- (void)alignBottom:(CGFloat)offet;
- (void)alignLeading:(CGFloat)offset;
- (void)alignTrailing:(CGFloat)offset;
- (void)alignWidth:(CGFloat)width;
- (void)alignHeight:(CGFloat)height;
- (void)alignSize:(CGSize)size;
- (void)alignFrame:(CGRect)frame;

- (void)alignInsets:(UIEdgeInsets)insets;

- (void)alignLeft:(CGFloat)offset relation:(NSLayoutRelation)relation;
- (void)alignTop:(CGFloat)offset relation:(NSLayoutRelation)relation;
- (void)alignRight:(CGFloat)offset relation:(NSLayoutRelation)relation;
- (void)alignBottom:(CGFloat)offet relation:(NSLayoutRelation)relation;
- (void)alignLeading:(CGFloat)offset relation:(NSLayoutRelation)relation;
- (void)alignTrailing:(CGFloat)offset relation:(NSLayoutRelation)relation;
- (void)alignWidth:(CGFloat)width relation:(NSLayoutRelation)relation;
- (void)alignHeight:(CGFloat)height relation:(NSLayoutRelation)relation;


- (void)fitX;
- (void)fitY;
- (void)fit;
- (void)fitXWithInset:(CGFloat)inset;
- (void)fitYWithInset:(CGFloat)inset;
- (void)fitWithInset:(CGFloat)inset;

+ (void)centerXinSuperview:(NSArray*)views;
+ (void)centerYinSuperview:(NSArray*)views;

- (void)alignHeightToWidth;
- (void)alignWidthToHeight;
- (void)alignHeightToWidth:(CGFloat)multiplier;
- (void)alignWidthToHeight:(CGFloat)multiplier;

#pragma mark - relations between two views

- (void)matchView:(FNView*)view;

- (void)matchView:(FNView*)view scale:(CGFloat)scale;

- (void)alignFrameToView:(FNView*)view
              scale:(CGFloat)multiplier
                  offset:(CGPoint)offset;

- (void)alignSizeToView:(FNView*)view
             scale:(CGFloat)multiplier;

- (void)alignWidthToView:(FNView*)view
              scale:(CGFloat)multiplier;

- (void)alignHeightToView:(FNView*)view
               scale:(CGFloat)multiplier;

- (void)alignCenterToView:(FNView*)view
                   offset:(CGPoint)offset;

- (void)alignCenterXtoView:(FNView*)view
                    offset:(CGFloat)offset;

- (void)alignCenterYtoView:(FNView*)view
                    offset:(CGFloat)offset;


- (void)alignTopToBottom:(FNView*)view
                  offset:(CGFloat)offset;
- (void)alignBottomToTop:(FNView*)view
                  offset:(CGFloat)offset;
- (void)alignLeftToRight:(FNView*)view
                  offset:(CGFloat)offset;
- (void)alignRightToLeft:(FNView*)view
                  offset:(CGFloat)offset;

- (void)alignTopToLeft:(FNView*)view
                offset:(CGFloat)offset;
- (void)alignLeftToTop:(FNView*)view
                offset:(CGFloat)offset;


- (void)alignTopEdges:(FNView*)view
               offset:(CGFloat)offset;
- (void)alignBottomEdges:(FNView*)view
                  offset:(CGFloat)offset;
- (void)alignLeftEdges:(FNView*)view
                offset:(CGFloat)offset;
- (void)alignRightEdges:(FNView*)view
                 offset:(CGFloat)offset;


/*
 " Invalid pairing of layout attributes "
 - (void)alignTopToWidth:(FNView*)view
 multiplier:(CGFloat)multiplier;
 
 - (void)alignTopToHeight:(FNView*)view
 multiplier:(CGFloat)multiplier;
 */

- (void)alignAttribute:(NSLayoutAttribute)myAttribute
                toView:(FNView*)view
             attribute:(NSLayoutAttribute)theirAttribute
            multiplier:(CGFloat)multiplier
              constant:(CGFloat)constant;







@end
