//
//  FNView+FNConstraintsViews.h
//  Wondr
//
//  Created by jonathan on 06/10/2014.
//  Copyright (c) 2014 Wondr.it Ltd. All rights reserved.
//
@import Foundation;
#if TARGET_OS_IPHONE
@import UIKit;
#define FNView UIView

#else
@import AppKit;
#define FNView NSView

#endif

void use_FNConstraintsViews();
extern NSInteger FORCE_LOAD_FNConstraintsViews;

//#define AddSubView(superview,subview)  \
//     [superview addView:subview withName:@#subview]




@interface FNView (FNConstraintsViews)
/*
 This category adds a constraintsView array to a FNView. The array tracks all subviews for which layoutConstraint changes are applicable. On 'updateLayoutConstraints' the array is used to remove all relevant constraints which are then rebuilt. This saves having to keep track of such a list per view, which often leads to crashes if the view is not actually instantiated when 'updateLayoutConstraints' is called.
 
 */

- (void)addView:(FNView*)view;
- (void)addView:(FNView *)view withName:(NSString*)name;

- (void)removeFromView;



- (NSMutableArray*)constraintsViews; //views array

- (NSMutableDictionary*)constrainedViews;  //views dictionary, suitable for ascii constraints views dict

//- (NSLayoutConstraint*)constraintForAttribute:(NSLayoutAttribute)attribute;

//- (NSLayoutConstraint*)constraintForFirstItem:(FNView*)firstItem
//                               firstAttribute:(NSLayoutAttribute)firstAttribute
//                                   secondItem:(FNView*)secondItem
//                              secondAttribute:(NSLayoutAttribute)secondAttribute;

//- (NSLayoutConstraint*)constraintForView:(FNView*)view
//                               attribute:(NSLayoutAttribute)attribute;

- (void)addSpacers:(int)numberOfSpacers;

@end


