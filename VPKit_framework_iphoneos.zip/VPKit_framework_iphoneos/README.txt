VPKit.framework

A thin dynamic build of the VPKit framework compiled for iphoneos devices.

This build is suitable for app store submission but is not compatible with iOS Simulator.


