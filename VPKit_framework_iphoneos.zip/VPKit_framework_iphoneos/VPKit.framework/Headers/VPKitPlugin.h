//
//  VPKitPlugin.h
//  VPKit
//
//  Created by jonathan on 07/11/2018.
//  Copyright © 2018 jonathan. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol VPKitPlugin <NSObject>

/**
 SDK initialization.
 
 This method is usually called from your App Delegate
 
 Obtain these credentials by registering your app with the VEEPIO developer portal
 https://developer.veep.io
 
 @param clientId - OAuth2 client_id credential
 @param clientSecret - OAuth2 client_secret credential
 
 
 
 */
+ (void)setApplicationId:(nonnull NSString*)appName
                clientId:(nullable NSString*)clientId
            clientSecret:(nullable NSString*)clientSecret;

- (void)setApplicationId:(nonnull NSString*)appName
                clientId:(nullable NSString*)clientId
            clientSecret:(nullable NSString*)clientSecret;

@end

NS_ASSUME_NONNULL_END
