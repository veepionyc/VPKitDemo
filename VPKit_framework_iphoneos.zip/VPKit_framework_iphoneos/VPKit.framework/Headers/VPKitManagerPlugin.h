//
//  VPKitManagerPlugin.h
//  VPKit
//
//  Created by jonathan on 07/11/2018.
//  Copyright © 2018 jonathan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VPKitPlugin.h"
#import "VPKPreviewPlugin.h"
#import "VPKImagePlugin.h"

NS_ASSUME_NONNULL_BEGIN

@protocol VPKitManagerPlugin <NSObject>
- (void)setApplicationId:(nonnull NSString*)appName
                clientId:(nullable NSString*)clientId
            clientSecret:(nullable NSString*)clientSecret;

- (NSString*)sdkVersion;

- (UIImageView <VPKPreviewPlugin> *)preview;

- (UIImage <VPKImagePlugin> *)newImageWithImage:(UIImage*)image veepId:(nullable NSString*)veepId;

- (UIImage <VPKImagePlugin> *)newImageWithImage:(UIImage*)image url:(NSURL*)url;


@end
NS_ASSUME_NONNULL_END
