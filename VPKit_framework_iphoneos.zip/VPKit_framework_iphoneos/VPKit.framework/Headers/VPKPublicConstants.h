//
//  Header.h
//  VPKit
//
//  Created by jonathan on 09/05/2018.
//  Copyright © 2018 jonathan. All rights reserved.
//

#ifndef VPKPublicConstants_h
#define VPKPublicConstants_h


#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString* const vpkErrorNotification;
FOUNDATION_EXPORT NSString* const vpkErrorKey;
FOUNDATION_EXPORT NSString* const vpkPresentErrorKey;

#endif /* Header_h */
