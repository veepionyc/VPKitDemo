//
//  SuperVC.h
//  safeInsets
//
//  Created by jonathan on 20/10/2017.
//  Copyright © 2017 jonathan. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SuperVC : UIViewController

- (UIEdgeInsets)safeInsets;
@end
